screen -dmS farmr1_xxx_nft_
sleep 1
screen -S farmr1_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@5.161.130.139 'bash /root/AutoRclone/autoClone/auto-mount.sh n/$1 1 15 $2 $3'^M" 
echo "chia-nft-farmer1"


#screen -dmS har0_xxx_nft_
#sleep 1
#screen -S har0_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@5.161.94.205 'bash /root/AutoRclone/autoClone/auto-mount.sh x/$1 31 45 $2 $3'^M"
#echo "chia-0"

#sleep 150
#screen -ls | awk -vFS='\t|[.]' '/_xxx_nft_/ {system("screen -S "$2" -X quit")}'
