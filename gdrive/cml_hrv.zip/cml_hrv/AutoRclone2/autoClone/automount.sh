drive=$1
echo "D: $drive"

#NFT
screen -dmS farmr1_xxx_nft_
sleep 1
screen -S farmr1_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@5.161.130.139 'bash /root/AutoRclone/autoClone/mount_nft_fr_1.sh $drive 1 1 nft'^M"
echo "chia-nft-farmr1"

screen -dmS har1_xxx_nft_
sleep 1
screen -S har1_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@5.161.129.105 'bash /root/AutoRclone/autoClone/mount.sh $drive 31 2 nft'^M"
echo "chia-nft-har-1"

screen -dmS har2_xxx_nft_
sleep 1
screen -S har2_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@5.161.86.168  'bash /root/AutoRclone/autoClone/mount.sh $drive 61 3 nft'^M"
echo "chia-nft-har-2"

screen -dmS har3_xxx_nft_
sleep 1
screen -S har3_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@5.161.187.72  'bash /root/AutoRclone/autoClone/mount.sh $drive 91 4 nft'^M"
echo "chia-nft-har-3"

screen -dmS har4_xxx_nft_
sleep 1
screen -S har4_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@5.161.183.239 'bash /root/AutoRclone/autoClone/mount.sh $drive 121 5 nft'^M"
echo "chia-nft-har-4"

screen -dmS har5_xxx_nft_
sleep 1
screen -S har5_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@5.161.189.108 'bash /root/AutoRclone/autoClone/mount.sh $drive 151 6 nft'^M"
echo "chia-nft-har-5"

screen -dmS har6_xxx_nft_
sleep 1
screen -S har6_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@5.161.80.58   'bash /root/AutoRclone/autoClone/mount.sh $drive 181 7 nft'^M"
echo "chia-nft-har-6"

screen -dmS har7_xxx_nft_
sleep 1
screen -S har7_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@5.161.78.54   'bash /root/AutoRclone/autoClone/mount.sh $drive 211 8 nft'^M"
echo "chia-nft-har-7"

screen -dmS har8_xxx_nft_
sleep 1
screen -S har8_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@5.161.177.200 'bash /root/AutoRclone/autoClone/mount.sh $drive 241 9 nft'^M"
echo "chia-nft-har-8"

screen -dmS har9_xxx_nft_
sleep 1
screen -S har9_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@5.161.188.31  'bash /root/AutoRclone/autoClone/mount.sh $drive 271 10 nft'^M"
echo "chia-nft-har-9"

#screen -dmS har1_xxx_nft_
#sleep 1
#screen -S har1_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@5.161.188.31  'bash /root/AutoRclone/autoClone/mount.sh $drive 301 11 nft'^M"

#MDK
echo "chia-nft-1"

screen -dmS Farmer1_xxx_MDK_
sleep 1
screen -S Farmer1_xxx_MDK_ -X stuff  "sshpass -p 'mdkroot.123' ssh root@5.161.108.157 'bash /root/AutoRclone/autoClone/mount.sh $drive 1 1 mdk'^M"
echo "chia-MDK-Farmer-1"

screen -dmS har1_xxx_MDK_
sleep 1
screen -S har1_xxx_MDK_ -X stuff  "sshpass -p 'mdkroot.123' ssh root@5.161.85.141  'bash /root/AutoRclone/autoClone/mount.sh $drive 31 2 mdk'^M"
echo "chia-MDK-HARV-1"

screen -dmS har2_xxx_MDK_
sleep 1
screen -S har2_xxx_MDK_ -X stuff  "sshpass -p 'mdkroot.123' ssh root@5.161.101.92  'bash /root/AutoRclone/autoClone/mount.sh $drive 61 3 mdk'^M"
echo "chia-MDK-HARV-2"

screen -dmS har3_xxx_MDK_
sleep 1
screen -S har3_xxx_MDK_ -X stuff  "sshpass -p 'mdkroot.123' ssh root@5.161.72.203  'bash /root/AutoRclone/autoClone/mount.sh $drive 91 4 mdk'^M" 
echo "chia-MDK-HARV-3"

#OG
echo "chia-nft-1"

screen -dmS Farmer1_xxx_OG_
sleep 1
screen -S Farmer1_xxx_OG_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@5.161.98.42   'bash /root/AutoRclone/autoClone/mount.sh $drive 1 1 og'^M"
echo "chia-OG-Farmer-1"

screen -dmS har1_xxx_OG_
sleep 1
screen -S har1_xxx_OG_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@154.38.160.19 'bash /root/AutoRclone/autoClone/mount.sh $drive 31 2 og'^M"
echo "chia-OG-1"

screen -dmS har2_xxx_OG_
sleep 1
screen -S har2_xxx_OG_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@154.38.160.27 'bash /root/AutoRclone/autoClone/mount.sh $drive 61 3 og'^M"
echo "chia-OG-2"

screen -dmS har3_xxx_OG_
sleep 1
screen -S har3_xxx_OG_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@154.38.160.18 'bash /root/AutoRclone/autoClone/mount.sh $drive 91 4 og'^M"
echo "chia-OG-3"

screen -dmS har4_xxx_OG_
sleep 1
screen -S har4_xxx_OG_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@154.38.160.26 'bash /root/AutoRclone/autoClone/mount.sh $drive 121 5 og'^M"
echo "chia-OG-4"

screen -dmS har5_xxx_OG_
sleep 1
screen -S har5_xxx_OG_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@154.38.160.25 'bash /root/AutoRclone/autoClone/mount.sh $drive 151 6 og'^M"
echo "chia-OG-5"

screen -dmS har6_xxx_OG_
sleep 1
screen -S har6_xxx_OG_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@154.38.160.24 'bash /root/AutoRclone/autoClone/mount.sh $drive 181 7 og'^M"
echo "chia-OG-6"

screen -dmS har7_xxx_OG_
sleep 1
screen -S har7_xxx_OG_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@154.38.160.23 'bash /root/AutoRclone/autoClone/mount.sh $drive 211 8 og'^M"
echo "chia-OG-7"

screen -dmS har8_xxx_OG_
sleep 1
screen -S har8_xxx_OG_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@154.38.160.22 'bash /root/AutoRclone/autoClone/mount.sh $drive 241 9 og'^M"
echo "chia-OG-8"

screen -dmS har9_xxx_OG_
sleep 1
screen -S har9_xxx_OG_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@154.38.160.21 'bash /root/AutoRclone/autoClone/mount.sh $drive 271 10 og'^M"
echo "chia-OG-9"

screen -dmS har10_xxx_OG_
sleep 1
screen -S har10_xxx_OG_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@154.38.160.20 'bash /root/AutoRclone/autoClone/mount.sh $drive 301 11 og'^M"
echo "chia-OG-10"

#NFT FARMER 2nd part
sleep 60
screen -dmS farmr1_xxx_nft_2
screen -S farmr1_xxx_nft_2 -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@5.161.130.139 'bash /root/AutoRclone/autoClone/mount_nft_fr_2.sh $drive 15 1 nft'^M"
echo "chia-nft-Farmer-1-2"


sleep 250
screen -ls | awk -vFS='\t|[.]' '/_xxx_/ {system("screen -S "$2" -X quit")}'
