#!/bin/bash
remote_group=$1
sa_group=$2
drive=$3
mountdir=$4
sa=$5 #dir
fusermount -uz /root/drives/drive$mountdir\_$sa

fusermount -uz /root/drives/drive$mountdir\_$sa/bucket$sa

umount /root/drives/drive$mountdir\_$sa/bucket$sa
sleep 1

#16K
mkdir /root/drives/drive$mountdir\_$sa
mkdir /root/drives/drive$mountdir\_$sa/bucket$sa

echo "mounting ...... XGDrive$remote_group\_$drive:mdk/bucket$dir /root/drives/drive$mountdir_$dir/bucket$dir"

rclone mount XGDrive$remote_group\_$drive:mdk/bucket$sa /root/drives/drive$mountdir\_$sa/bucket$sa  --vfs-cache-mode off --multi-thread-streams 30 --low-level-retries 2 --retries 2 --vfs-read-chunk-size 128K --drive-chunk-size 1M --buffer-size off --max-backlog 20000 --no-traverse --no-modtime --read-only --log-level INFO --stats 1m --allow-non-empty --max-duration 0 --no-checksum --max-read-ahead=0K --vfs-read-chunk-size-limit off --timeout 0 --drive-keep-revision-forever --drive-stop-on-download-limit --drive-v2-download-min-size 256M --daemon

#rclone mount XGDrive$remote_group\_$drive:mdk/bucket$sa /root/drives/drive$mountdir\_$sa/bucket$sa --vfs-cache-max-age 1000000h --vfs-cache-max-size 0.5G --vfs-cache-mode full --vfs-read-chunk-size 128k --poll-interval 24h --checkers 2 --no-check-certificate --vfs-read-chunk-size-limit 0 --max-read-ahead 0 --vfs-read-wait 0 --buffer-size off --no-checksum --no-modtime --read-only --daemon

#rclone mount XGDrive$remote_group\_$drive:mdk/bucket$sa /root/drives/drive$mountdir\_$sa/bucket$sa  --allow-non-empty --daemon  --cache-workers=4 -o ThreadCount=4 --multi-thread-streams=8 --multi-thread-cutoff=0 --dir-cache-time=1h --poll-interval=30m --vfs-cache-poll-interval=30m --vfs-cache-mode=off --vfs-read-chunk-size=128K --max-read-ahead=0 --use-mmap --local-no-check-updated --buffer-size=off --no-checksum --no-modtime --checkers=0 --use-cookies --read-only

#rclone mount XGDrive$remote_group\_$drive:mdk/bucket$sa /root/drives/drive$mountdir\_$sa/bucket$sa  --drive-service-account-file /root/AutoRclone/accounts/accounts_$remote_group/$sa_group/$sa.json  --allow-non-empty --daemon  --cache-workers=4 -o ThreadCount=4 --multi-thread-streams=8 --multi-thread-cutoff=0 --dir-cache-time=1h --poll-interval=30m --vfs-cache-poll-interval=30m --vfs-cache-mode=off --vfs-read-chunk-size=128K --max-read-ahead=0 --use-mmap --local-no-check-updated --buffer-size=off --no-checksum --no-modtime --checkers=0 --use-cookies --read-only


#rclone mount XGDrive$1_$5:bucket$2 /root/drives/drive$6_$2/bucket$2 --drive-service-account-file /root/AutoRclone/accounts/accounts_$4/$index.json  --allow-non-empty --daemon  --cache-workers=4 -o ThreadCount=4 --multi-thread-streams=8 --multi-thread-cutoff=0 --dir-cache-time=1h --poll-interval=30m --vfs-cache-poll-interval=30m --vfs-cache-mode=off --vfs-read-chunk-size=16K --max-read-ahead=0 --use-mmap --local-no-check-updated --buffer-size=off --no-checksum --no-modtime --checkers=0 --use-cookies --read-only

