#!/bin/bash
remote_group=$1
sa_group=$2
drive=$3
mountdir=$4
dir=$5

while [ $dir -le $6 ]
do                                                #--*2_NFT_*1_*1-*11-*1-30--
        bash /root/AutoRclone/autoClone/asafm_nft_sub.sh $remote_group $sa_group $drive $mountdir $dir
        sleep 1
        dir=$(($dir + 1))
done

#while [ 1 -le 2 ]
#do
#	echo "Check Mounts"
#	bash /root/AutoRclone/autoClone/check-mount-sub.sh $1 $2 $3 $4 $5 $6 nft
#	sleep 10
#done

sleep 3
echo "Check Mounts 1"
bash /root/AutoRclone/autoClone/check-mount-sub.sh $1 $2 $3 $4 $5 $6 nft

sleep 40
echo "Check Mounts 2"

bash /root/AutoRclone/autoClone/check-mount-sub.sh $1 $2 $3 $4 $5 $6 nft

sleep 1m
echo "Check Mounts 3"

bash /root/AutoRclone/autoClone/check-mount-sub.sh $1 $2 $3 $4 $5 $6 nft

sleep 2m
echo "Check Mounts 4"

bash /root/AutoRclone/autoClone/check-mount-sub.sh $1 $2 $3 $4 $5 $6 nft

sleep 3m
echo "Check Mounts 5"

bash /root/AutoRclone/autoClone/check-mount-sub.sh $1 $2 $3 $4 $5 $6 nft
