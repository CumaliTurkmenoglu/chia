remote_group=$1
sa_group=$2
screen -dmS farmr1_nft_
sleep 1   ###$remote_group: 2_NFT, [$sa_group: 1 or 1:remote_mail] 11:folder_mount 1:from 30:to
screen -S farmr1_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.251 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft_2.sh $remote_group $sa_group  901 11 1 14 '^M"
echo "chia-farmr1_nft_"

screen -dmS farmr2_nft_
sleep 1   
screen -S farmr2_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.25 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group  902 11 31 61 '^M"
echo "chia-farmr2_nft_"																																						


screen -dmS har1_xxx_nft_   
sleep 1 
screen -S har1_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.27 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 1 11 61 90 '^M"
echo "chia-nft-1"   

screen -dmS har2_xxx_nft_   
sleep 1 
screen -S har2_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.29 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 2 11 91 120 '^M"
echo "chia-nft-2"   

screen -dmS har3_xxx_nft_   
sleep 1 
screen -S har3_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.30 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 3 11 121 150 '^M"
echo "chia-nft-3"   

screen -dmS har4_xxx_nft_   
sleep 1 
screen -S har4_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.31 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 4 11 151 180 '^M"
echo "chia-nft-4"   

screen -dmS har5_xxx_nft_   
sleep 1 
screen -S har5_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.34 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 5 11 181 210 '^M"
echo "chia-nft-5"   

screen -dmS har6_xxx_nft_   
sleep 1 
screen -S har6_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.36 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 6 11 211 240 '^M"
echo "chia-nft-6"   

screen -dmS har7_xxx_nft_   
sleep 1 
screen -S har7_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.37 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 7 11 241 270 '^M"
echo "chia-nft-7"   

screen -dmS har8_xxx_nft_   
sleep 1 
screen -S har8_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.38 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 8 11 271 300 '^M"
echo "chia-nft-8"   

screen -dmS har9_xxx_nft_   
sleep 1 
screen -S har9_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.39 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 9 11 301 330 '^M"
echo "chia-nft-9"   

screen -dmS har10_xxx_nft_  
sleep 1 
screen -S har10_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.42 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 10 11 331 360 '^M"
echo "chia-nft-10"  

screen -dmS har11_xxx_nft_  
sleep 1 
screen -S har11_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.43 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 11 11 361 390 '^M"
echo "chia-nft-11"  

screen -dmS har12_xxx_nft_  
sleep 1 
screen -S har12_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.44 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 12 11 391 420 '^M"
echo "chia-nft-12"  

screen -dmS har13_xxx_nft_  
sleep 1 
screen -S har13_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.45 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 13 11 421 450 '^M"
echo "chia-nft-13"  

screen -dmS har14_xxx_nft_  
sleep 1 
screen -S har14_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.19 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 14 11 451 480 '^M"
echo "chia-nft-14"  

screen -dmS har15_xxx_nft_  
sleep 1 
screen -S har15_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.183 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 15 11 481 510 '^M"
echo "chia-nft-15"  

screen -dmS har16_xxx_nft_  
sleep 1 
screen -S har16_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.197 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 16 11 511 540 '^M"
echo "chia-nft-16"  

screen -dmS har17_xxx_nft_  
sleep 1 
screen -S har17_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.198 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 17 11 541 570 '^M"
echo "chia-nft-17"  

screen -dmS har18_xxx_nft_  
sleep 1 
screen -S har18_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.199 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 18 11 571 600 '^M"
echo "chia-nft-18"  

screen -dmS har19_xxx_nft_  
sleep 1 
screen -S har19_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@45.88.168.131 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 19 11 601 630 '^M"
echo "chia-nft-19"  

screen -dmS har20_xxx_nft_  
sleep 1 
screen -S har20_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@63.251.217.102 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 20 11 631 660 '^M"
echo "chia-nft-20"  

screen -dmS har21_xxx_nft_  
sleep 1 
screen -S har21_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@45.12.138.166 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 21 11 661 690 '^M"
echo "chia-nft-21"

screen -dmS har22_xxx_nft_
sleep 1
screen -S har22_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@171.22.109.160 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 22 11 691 720 '^M"
echo "chia-nft-22"

# screen -dmS har23_xxx_nft_
# sleep 1
# screen -S har23_xxx_nft_ -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@63.251.217.102 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group 23 11 691 720 '^M"
# echo "chia-nft-23"

sleep 2m

screen -dmS farmr1_nft_222
sleep 1   ###$remote_group: 2_NFT, [$sa_group: 1 or 1:remote_mail] 11:folder_mount 1:from 30:to
screen -S farmr1_nft_222 -X stuff  "sshpass -p 'Serhildanroot.123' ssh root@66.151.116.251 'bash /root/AutoRclone/autoClone/auto-mount-sub-nft.sh $remote_group $sa_group  901 11 15 30 '^M"
echo "chia-farmr1_nft_222"


#sleep 150
#screen -ls | awk -vFS='\t|[.]' '/_xxx_nft_/ {system("screen -S "$2" -X quit")}'