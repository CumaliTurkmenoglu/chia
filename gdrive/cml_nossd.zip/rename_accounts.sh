#!/bin/bash
# $1 : dir, $2 suffix if exist.

index=1
for FILENAME in /root/sa/accounts_$1/*.json
do
        mv $FILENAME  /root/sa/accounts_$1/$index$2.json
        index=$(($index+1))
done