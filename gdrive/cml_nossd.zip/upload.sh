#!/bin/bash
check_drive() {
    local upload_folder=$1
    local sa=$2

    echo "Saglik kontrolu" > health_check.txt
    if rclone copy health_check.txt "$upload_folder": --drive-service-account-file "$sa" --retries 2 &&
       rclone ls "$upload_folder": --drive-service-account-file "$sa" | grep -q "health_check.txt"; then
        return 0 # Drive saglam
    else
        return 1 # Drive saglam degil
    fi
}



max_value=$1
while :
do
    file_count=$(ls -lA "/root/sa/accounts_up/" | grep "^-" | wc -l)
    sa=$((RANDOM % file_count + 1))

    # Her iterasyonda farkli bir root folder'a XGDriveUP_$n yükle
    upload_folder="XNOSSDUP_$((RANDOM % max_value + 1))"
    
	if check_drive "$upload_folder" "$sa"; then
        # Eger Drive saglamsa, dosyalari yukle
		echo  "plotlar buraya upload ediliyor = $upload_folder"    
		rclone delete "$upload_folder":health_check.txt
		rclone move /plots $upload_folder: --progress --drive-upload-cutoff 1000T --multi-thread-streams 32 --tpslimit 5 --exclude "/*.tmp" --transfers 4 --drive-stop-on-upload-limit --drive-chunk-size 1024M --no-traverse --ignore-existing --log-level INFO -P --drive-service-account-file /root/sa/accounts_up/$sa.json
    else
        echo "Secilen Drive saglam degil, baska bir Drive denenecek."
    fi

    sleep 2
done


