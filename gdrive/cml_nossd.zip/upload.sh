#!/bin/bash
check_drive() {
    local upload_folder_check=$1
    local sa=$2

    echo "Saglik kontrolu" > health_check.txt
    if rclone copy health_check.txt "$upload_folder_check": --retries 2 &&
       rclone ls "$upload_folder_check": | grep -q "health_check.txt"; then
        return 0 # Drive saglam
    else
		echo "$upload_folder_check $upload_folder_check $upload_folder_check $upload_folder_check"
        return 1 # Drive saglam degil
    fi
}


start_drive=$1
max_drive=$2
while :
do
    file_count=$(ls -lA "/root/sa/accounts_up/" | grep "^-" | wc -l)
    sa=$((RANDOM % file_count + 1))

    # Her iterasyonda farkli bir root folder'a XGDriveUP_$n yükle
    upload_folder_check="NOSSDUP_$((RANDOM % max_drive + start_drive))"
	upload_folder="XNOSSDUP_$((RANDOM % max_drive + start_drive))"

        if check_drive "$upload_folder_check" "$sa"; then
        # Eger Drive saglamsa, dosyalari yukle
                echo  "plotlar buraya upload ediliyor = $upload_folder"
                rclone delete "$upload_folder_check":health_check.txt
                gclone move /plots $upload_folder: --progress --drive-upload-cutoff 1000T --multi-thread-streams 32 --tpslimit 5 --exclude "/*.tmp" --exclude "/*.fpt_part" --transfers 4 --drive-stop-on-upload-limit --drive-chunk-size 1024M --no-traverse --ignore-existing --log-level INFO -P --drive-service-account-file /root/sa/accounts_up/$sa.json
    else
        echo "Secilen Drive saglam degil, baska bir Drive denenecek."
    fi

    sleep 2
done


