#!/bin/bash

generate_random_user_agent() {
    local platforms=("Windows NT 10.0; Win64; x64" "Macintosh; Intel Mac OS X 10_15_7" "X11; Linux x86_64" "iPhone; CPU iPhone OS 13_2_3 like Mac OS X" "Android 9; Mobile; rv:68.0")
    local browsers=("Chrome/90.0.4430.212" "Safari/605.1.15" "Firefox/88.0" "Edge/90.0.818.62" "OPR/76.0.4017.123")
    local platform=${platforms[$RANDOM % ${#platforms[@]}]}
    local browser=${browsers[$RANDOM % ${#browsers[@]}]}
    echo "Mozilla/5.0 ($platform) AppleWebKit/537.36 (KHTML, like Gecko) $browser Safari/537.36"
}


test_file_path="/plots/deneme.txt"
# deneme.txt dosyasını kontrol et ve gerekirse oluştur
ensure_test_file_exists() {
    if [ ! -f "$test_file_path" ]; then
        echo "Bu bir test dosyasidir." > "$test_file_path"
    fi
}

test_upload_and_retrieve() {
    local folder=$1
    local test_file="deneme.txt"
    local source_path="/plots/$test_file"
    file_count=$(ls -lA "/root/sa/accounts_up/" | grep "^-" | wc -l)
    sa=$((RANDOM % file_count + 1))

    # Test dosyasını yükle
    if gclone move "$source_path" "$folder": --drive-service-account-file "$service_account_file" --drive-stop-on-upload-limit; then
        echo "Yükleme başarılı oldu, OK!"
    else
        echo "Yükleme başarısız oldu, hedef kullanılamaz"
        return 1
    fi
    return 0
}

AGENT=$(generate_random_user_agent)
start_drive=$1
max_drive=$2

while :
do
    ensure_test_file_exists
    upload_folder="XNOSSDUP_$((RANDOM % max_drive + start_drive))"
    upload_folder_deneme="NOSSDUP_$((RANDOM % max_drive + start_drive))"
    file_count=$(ls -lA "/root/sa/accounts_up/" | grep "^-" | wc -l)
    sa=$((RANDOM % file_count + 1))

    if ! test_upload_and_retrieve "$upload_folder_deneme"; then
        echo -e "\e[92m"$upload_folder": kullanilamaz durumda, yeni bir hedef deneniyor...\e[0m"
        continue
    fi

    echo -e "\e[92m"$upload_folder": kullanilabilir, plotlar buraya yukleniyor...\e[0m"
    # Dosya yükleme komutları burada
    gclone move /plots "$upload_folder": --progress --drive-upload-cutoff 1000T --multi-thread-streams 128 --tpslimit 12 --tpslimit-burst 12 --exclude "/*.fpt_part" --transfers 3 --exclude "/*.txt" --exclude "/*.tmp" --drive-stop-on-upload-limit --drive-chunk-size 1Gi --no-traverse --log-level INFO -P --drive-service-account-file "/root/sa/accounts_up/$sa.json"

    sleep 2
done
