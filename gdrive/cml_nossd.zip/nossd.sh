#!/usr/bin/env bash

cd /root/nossd-2.3/linux

./client -d /plots --no-benchmark -c $1 --no-stop  #--p-threads 63 -m 124G