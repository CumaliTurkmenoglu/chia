#!/usr/bin/env bash

cd /root/nossd-2.3/linux

./client -d /plots --no-benchmark -c 10 --no-stop  #--p-threads $1 -m $2G