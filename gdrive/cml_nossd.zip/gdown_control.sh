sudo apt install python3-pip -y
pip install gdown
pip install --upgrade gdown

while :
do
        gdown https://drive.google.com/drive/folders/1xLDqQg5J0iIlY0i41YMx9iGpzxJBfMEz -O /tmp/folder --folder --remaining-ok
        rm -r /tmp/folder
        n=$(( ( RANDOM % 3000)  + 300 ))
        sleep $n
