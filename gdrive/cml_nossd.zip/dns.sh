#!/bin/bash

# DNS adreslerini içeren bir dizi
dns_servers=(
    "9.9.9.9" "149.112.112.112"         # Quad9 DNS
    "208.67.222.222" "208.67.220.220"   # OpenDNS
    "64.6.64.6" "64.6.65.6"             # Verisign DNS
    "77.88.8.8" "77.88.8.1"             # Yandex DNS
    "84.200.69.80" "84.200.70.40"       # DNS.Watch
    "8.26.56.26" "8.20.247.20"          # Comodo Secure DNS
    "195.46.39.39" "195.46.39.40"       # SafeDNS
    "69.195.152.204" "23.94.60.240"     # GreenTeamDNS
    "156.154.70.1" "156.154.71.1"       # Neustar DNS
    "45.77.165.194"                     # Fourth Estate DNS
    "101.101.101.101" "101.102.103.104" # SK Broadband DNS
    "103.86.96.100" "103.86.99.100"     # NordVPN DNS
    "185.228.168.9" "185.228.169.9"     # CleanBrowsing DNS
    "76.76.19.19" "76.223.122.150"      # ControlD DNS
    "94.140.14.14" "94.140.15.15"       # AdGuard DNS
    "176.103.130.130" "176.103.130.131" # AdGuard Family Protection
    "66.244.95.20" "66.45.252.237"      # SmartViper DNS
    "91.239.100.100" "89.233.43.71"     # UncensoredDNS
    "156.154.70.5" "156.154.71.5"        # UltraDNS
)


# Aktif ag arayüzünü bul
active_interface=$(ip route get 1.2.3.4 | awk '{print $5}' | head -n 1)

while true; do
    for dns in "${dns_servers[@]}"; do
        # DNS adresini güncelle
        sudo resolvectl dns $active_interface $dns
        sudo resolvectl flush-caches

        # DNS degisikligini ve mevcut DNS ayarlarini ekrana yazdir
        echo "DNS changed to $dns on interface $active_interface"
        resolvectl status $active_interface | grep "DNS Servers"

        # 30 saniye bekle
        sleep 30
    done
