#!/bin/bash
mkdir /root/sa/accounts_temp/
while :
do
        for FILENAME in /root/sa/accounts_up/*;
        do
                if rclone ls XNOSSDUP_1: --log-level INFO -P --drive-service-account-file $FILENAME 2>&1 | grep -q "oauth2: cannot fetch token: 400 Bad Request"; then
                        echo "Error found: oauth2: cannot fetch token: 400 Bad Request"
                        rm $FILENAME
                else
                        echo "SA is OK! $FILENAME"
                fi
        done
        cd
        rm sa.zip*
        wget --no-check-certificate https://github.com/CumaliTurkmenoglu/chia/raw/main/gdrive/sa.zip
        unzip sa.zip -d /root/sa/accounts_temp/
        bash /root/rename_accounts_rnd.sh up
        bash /root/rename_accounts_rnd.sh temp
        find /root/sa/accounts_temp/ -maxdepth 1 -type f -exec mv -t /root/sa/accounts_up/ {} +
        #mv /root/sa/accounts_temp/* /root/sa/accounts_up/
        bash /root/rename_accounts.sh up

        sleep 24h
done