#!/bin/bash
index=1
for FILENAME in /root/sa/accounts_$1/*.json; 
do
        random="${RANDOM}${RANDOM}${RANDOM}"
        mv $FILENAME  /root/sa/accounts_$1/$index_$random.json; 
        index=$(($index+1))
done