#!/bin/bash

LOG_FILE="/root/AutoRclone/copy.log"

while :
do
    timeout 15 /usr/bin/python3 /root/AutoRclone/autorclone.py XGDriveUP_main XGDriveUP_copy copy >> "$LOG_FILE" 2>&1

done
