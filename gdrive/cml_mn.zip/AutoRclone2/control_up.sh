while :
do
/usr/bin/python3 /root/AutoRclone/autorclone_2.py 1 XGDriveUP_$1 move
sleep 10
done

