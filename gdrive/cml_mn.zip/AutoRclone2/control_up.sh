while :
do
/usr/bin/python3 /root/AutoRclone/autorclone.py 1 XGDriveUP_$1 move
sleep 10
done

