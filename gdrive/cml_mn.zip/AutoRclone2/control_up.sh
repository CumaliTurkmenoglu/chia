screen -ls | awk -vFS='\t|[.]' '/clone/ {system("screen -S "$2" -X quit")}'
sleep 5
screen -dmS clone
drive=$1
while :
do
        sleep 5
        screen -S clone -X stuff  "^C ^M"
        screen -S clone -X stuff  "echo  '/usr/bin/python3 /root/AutoRclone/autorclone.py dummy XGDriveUP_$drive move' ^M" 
        screen -S clone -X stuff  "/usr/bin/python3 /root/AutoRclone/autorclone.py dummy XGDriveUP_$drive move ^M"
        sleep 12h
        drive=$(($drive+1))
        if [ $drive -gt $2 ]
         then
                drive=$1
        fi
done