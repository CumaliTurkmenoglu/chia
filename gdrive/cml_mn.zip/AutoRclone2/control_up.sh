while :
do
/usr/bin/python3 /root/AutoRclone/autorclone.py XGDriveUP_$1 $2
sleep 30
done

